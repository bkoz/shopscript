<?php
return array(
    'app.installer'=>array(
        'version'=>'>=1.7.5',
        'strict'=>true,
    ),
);
//EOF