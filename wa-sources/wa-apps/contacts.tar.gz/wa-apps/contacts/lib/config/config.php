<?php

return array(
    'paginator_type' => 'range'      // page, range
);

