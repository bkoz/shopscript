<?php

if (wa()->appExists('contacts')) {
    wa('contacts');
}
