<?php

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'version' => '1.7.6',
    'critical'=>'1.7.3',
    'vendor' => 'webasyst',
);
